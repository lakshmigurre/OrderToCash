//
//  TestMultiplierTask.h
//  TaskFrameworkLibrary
//
//  Created by MADP on 26/09/16.
//  Copyright © 2016 MADP. All rights reserved.
//

#import "KSTask.h"

@interface TestMultiplierTask : KSTask
{
@private
    NSString *_inputParamName;
    NSString *_outputParamName;
}

@property (nonatomic,strong) NSString *inputParamName;
@property (nonatomic,strong) NSString *outputParamName;
@property (nonatomic) int numberToMultiply;

- (instancetype)initWithInputParam:(NSString*)inputParamName
                      AndOutputParam:(NSString*)outputParamName
                           AndNumber:(int)numberToMultiply;

- (void) execute;

@end
